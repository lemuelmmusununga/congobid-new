<?php

return [

    /*
    |--------------------------------------------------------------------------
    | All contents  for congobid
    |--------------------------------------------------------------------------
    */

    'title-index' => 'Enchères en cours',
    'title-enchere-future' => 'Enchères futures',
    'title-enchere-ferme' => 'Enchères gagnées',

    'byBid' => 'Acheter de bids',
];
