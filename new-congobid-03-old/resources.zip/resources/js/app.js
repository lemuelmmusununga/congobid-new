require('./bootstrap');

import Alpine from 'alpinejs';
import 'chart.js';

window.Alpine = Alpine;

Alpine.start();
