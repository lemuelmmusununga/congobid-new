<header class="sticky-top">
    <nav class="navbar">
        <div class="container-fluid">
            <div class="block-user-chat w-100">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-6">
                        <div class="block-right">
                            <a href="javascript:history.go(-1)" class="back text-white">
                                <span>
                                    <span class="iconify" data-icon="la:angle-left"></span>
                                </span>
                                Retour
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-6 text-center text-white">
                        <h5 class="mb-0">Chat</h5>
                    </div>
                    <div class="col-lg-4 col-6">
                    </div>
                </div>

            </div>
        </div>
    </nav>
</header>
