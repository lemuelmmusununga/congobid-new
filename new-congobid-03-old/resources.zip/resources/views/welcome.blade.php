


@extends('layouts.app')

@section('content')
    <header id="header" class="header" >

        <div class="countdown">
            <span id="clock" class="text-black"></span>
        </div>

    </header
@endsection


