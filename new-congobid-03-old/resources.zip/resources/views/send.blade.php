<!DOCTYPE html>
<html>
<head>
    <title>Letecode.com </title>
</head>
<body>
    <h1> {{ $contenu['title'] }} </h1>
    <p> {{ $contenu['body'] }} </p>

    <p> CongoBid <br/> La Direction</p>

</body>
</html>
