<div >
    @include('components.favoris')
</div>
