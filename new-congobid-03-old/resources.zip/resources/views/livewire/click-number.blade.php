<div>
    <td><span class="badge bg-primary">{{$bid??'0'}}</span></td>
</div>
