@extends('layouts.app-profil')
@section('content')
    @livewire('encheres.enchere-futures')

@endsection
