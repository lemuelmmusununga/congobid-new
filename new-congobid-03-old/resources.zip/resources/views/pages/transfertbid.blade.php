@extends('layouts.app-page')
@section('content')
    <div class="block-page">
        @livewire('send-option')
    </div>
@endsection
