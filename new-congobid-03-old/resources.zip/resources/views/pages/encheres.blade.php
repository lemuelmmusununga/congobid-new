@extends('layouts.app-page')
@section('content')
    @livewire('encheres.enchere-encours')
@endsection
