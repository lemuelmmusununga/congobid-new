@extends('layouts.app-chatbox')
@section('content')
<div class="block-page">
    <div class="container">
        @livewire('content-chat')
    </div>
</div>
@endsection