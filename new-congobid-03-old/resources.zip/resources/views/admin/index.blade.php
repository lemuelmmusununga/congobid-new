@extends('admin.layouts.master')

@section('css')
@endsection

@section('body')

    @include('admin.layouts.partials.body.body-index')

@endsection

@section('javascript')
@endsection
