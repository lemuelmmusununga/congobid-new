
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<title>Congo bid</title>

	<!-- Fonts and icons -->
	<link rel="icon" href="{{ asset('images/logo.png') }}" type="image/x-icon"/>
